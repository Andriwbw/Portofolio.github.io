import SectionHeading from "@/components/section-heading"

export default function About() {
  return (
    <section id="about" className="container mx-auto px-4 py-16 md:py-24 scroll-mt-24" aria-labelledby="about-heading">
      <p className="text-xs text-muted-foreground mb-4">{"Home Page | 02"}</p>

      <SectionHeading title="About Me" />

      <div className="mt-8 grid md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <h3 className="text-lg font-medium">{"Introduction"}</h3>
          <p className="text-pretty">
            {
              "Hello! I'm Andri, a UI/UX designer with a strong passion for how technology and design can converge to solve real-world problems. For me, every project is an opportunity to learn about human behavior and to craft better digital experiences."
            }
          </p>
          <p className="text-pretty">
            {"My focus is always on placing the user at the heart of every design decision."}
          </p>
        </div>
        <div className="space-y-4">
          <h3 className="text-lg font-medium">{"About Portfolio"}</h3>
          <p className="text-pretty">
            {
              "I enjoy the entire design process, from initial research and creating wireframes to building interactive prototypes and delivering clean, compelling visual designs."
            }
          </p>
          <p className="text-pretty">
            {
              "This portfolio showcases my skills and projects in the UI/UX field—from e-learning platforms to movie booking applications—demonstrating my design process."
            }
          </p>
        </div>
      </div>
    </section>
  )
}
