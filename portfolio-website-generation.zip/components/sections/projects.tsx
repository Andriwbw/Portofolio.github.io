import SectionHeading from "@/components/section-heading"
import ProjectCard from "@/components/project-card"

export default function Projects() {
  return (
    <section
      id="projects"
      className="container mx-auto px-4 py-16 md:py-24 scroll-mt-24"
      aria-labelledby="projects-heading"
    >
      <p className="text-xs text-muted-foreground mb-4">{"Home Page | 03"}</p>

      <SectionHeading title="My Projects" />

      <div className="mt-8 grid md:grid-cols-2 gap-6">
        <ProjectCard
          imageSrc="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/unnamed%20%281%29-t5boe65IjkSGMnGSZuQsttbSAWrrCZ.png"
          imageAlt="Nextudy e-learning platform flows and screens"
          title="An Interactive E-Learning Platform"
          summary={`The Challenge: To design an online learning platform that is easy to navigate, visually engaging, and supports the user's learning process from start to finish, including content delivery and quiz-based evaluation. The Solution: I designed "Nextudy" with a clear user flow and a clean interface. Users can easily select subjects, access well-structured learning notes by chapter, and test their understanding through a series of interactive quizzes. The minimalist design aims to keep the user focused on the learning material.`}
          features={[
            "Home Page with clear subject navigation.",
            "Structured Learning Notes page.",
            "Interactive Quiz System with various question types.",
            "Quiz Results Page for instant feedback.",
            "Supporting features like a Class Schedule and a Feedback Page.",
          ]}
        />

        <ProjectCard
          imageSrc="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/unnamed-FFCSLDPY5Se0uu1sjye6YHDLH3ppdC.png"
          imageAlt="Movie Ticket Booking App user flow screens"
          title="Movie Ticket Booking App"
          summary={
            'The Challenge: To create a fast, easy, and seamless movie ticket booking experience, from film selection through to completing the transaction. The Solution: The user flow in "CinemaAndri" was designed to be linear and intuitive. Users can easily browse currently playing movies, read detailed synopses, select their preferred showtimes and seats, and confirm their order in just a few simple steps. A warm color palette was chosen to create a cozy and cinematic atmosphere.'
          }
          features={[
            "Simple User Registration & Login.",
            "A visually engaging Home Page with a film gallery.",
            "An informative Movie Detail Page.",
            "Visual and interactive Seat Selection.",
            "A clear and concise Order Confirmation flow.",
          ]}
        />
      </div>
    </section>
  )
}
