import { Phone, Globe, Mail, MapPin } from "lucide-react"

export default function Contact() {
  return (
    <section
      id="contact"
      className="container mx-auto px-4 py-16 md:py-24 scroll-mt-24"
      aria-labelledby="contact-heading"
    >
      <p className="text-xs text-muted-foreground mb-4">{"Home Page | 04"}</p>

      <h2 id="contact-heading" className="text-4xl md:text-6xl font-bold tracking-tight text-foreground">
        My Contact
      </h2>
      <div className="mt-3 h-1 w-16 border-t border-foreground" aria-hidden="true" />

      <p className="mt-8 max-w-3xl text-sm md:text-base leading-relaxed text-muted-foreground">
        I am currently based in Bekasi, West Java. I am always open to learning new things and collaborating on
        challenging projects. Feel free to reach out to me through any of the channels below. Let{"'"}s connect and
        create something great together!
      </p>

      <ul role="list" className="mt-10 space-y-6">
        <li className="flex items-center gap-4">
          <Phone className="h-5 w-5 text-foreground" aria-hidden="true" />
          <a href="tel:+6281717112234" className="text-sm md:text-base text-foreground hover:underline">
            +62-817-1711-2234
          </a>
        </li>

        <li className="flex items-center gap-4">
          <Globe className="h-5 w-5 text-foreground" aria-hidden="true" />
          <a
            href="https://www.linkedin.com/in/m-andri-wibowo-4467a6385/"
            target="_blank"
            rel="noreferrer"
            className="text-sm md:text-base text-foreground hover:underline break-all"
          >
            https://www.linkedin.com/in/m-andri-wibowo-4467a6385/
          </a>
        </li>

        <li className="flex items-center gap-4">
          <Mail className="h-5 w-5 text-foreground" aria-hidden="true" />
          <a href="mailto:andriwbw27@gmail.com" className="text-sm md:text-base text-foreground hover:underline">
            andriwbw27@gmail.com
          </a>
        </li>

        <li className="flex items-center gap-4">
          <MapPin className="h-5 w-5 text-foreground" aria-hidden="true" />
          <span className="text-sm md:text-base text-foreground">Bekasi, West Java</span>
        </li>
      </ul>
    </section>
  )
}

function ContactItem({
  label,
  value,
  href,
}: {
  label: string
  value: string
  href?: string
}) {
  const content = (
    <div className="rounded-lg border border-[var(--color-border)] p-4 h-full">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-1 font-medium">{value}</div>
    </div>
  )

  if (href) {
    return (
      <a
        href={href}
        target={href.startsWith("http") ? "_blank" : undefined}
        rel={href.startsWith("http") ? "noreferrer" : undefined}
        className="block hover:brightness-95 transition"
      >
        {content}
      </a>
    )
  }

  return content
}
